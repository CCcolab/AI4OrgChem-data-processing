---
name: table-fitting-residuals
description: 对明确变量、单位和观测含义的CSV实施带截距线性或二次最小二乘，记录权重和残差，或复算有来源的咖啡因校准，区分描述性拟合、预测与独立结果复核。
---

# 表格拟合与残差分析

先确认目的是描述、校准、预测还是复核既有结果。原始输入、单位和研究设计决定分析；不从截图补造数据，不为提高R²自动增加阶数、删点或强迫过原点。


## 配套程序已验证运行环境

**下列数据/数值功能已在本地运行成功；结论限定于列出的操作与案例。**

| 项目 | 已验证内容 |
| --- | --- |
| 操作系统 | Windows 11 |
| Python / 设备 | 3.12.14 / CPU |
| 本轮实际依赖范围 | numpy 2.4.6；matplotlib 3.11.2 |
| 本轮已验证功能 | 给定CSV的有界线性/二次最小二乘、加权拟合、残差/图表及结果保存；参数修改与已有结果保护 |
| 测试内容 | 02_linear、03_weighted、changed-degree、existing-output-protection；结果文件、ZIP CRC与SHA-256核对 |
| 测试结果 | 4/4项符合预期；含输入拒绝/旧结果保护，不表示所有命令退出0 |
| 历史运行记录 | 历史固定bb629ee版（2026-10-25）在Linux / Python 3.12.14 / CPU完成默认入口；不等于本修订版完整运行复验 |
| 验证日期 / 程序基线 | 2026-10-26 / 67aaaaa；本次只改说明与分发，不改计算程序 |
| 未覆盖范围 | 只验证给定小样本和有界次数；不认证实验误差模型、外推、因果或通用预测能力。 |

使用已有独立Python环境，没有在本轮重新安装依赖。通过所列小型案例不等于全部平台、输入分布或科学用途已认证。 输入准备、数值复核、模型训练与化学用途验证分别报告；全平台对照见[运行环境与验证范围](https://github.com/CCcolab/AI4OrgChem-data-processing/blob/main/docs/VERIFIED_ENVIRONMENTS.md)。


## 输入与范围

用户CSV为UTF-8，≤128000字节、最多1000条，列id,x,y，可选独立sigma列。ID非空唯一且保留文本；重复观测使用不同ID。全部数值有限，不静默删除缺失或异常值。x至少有足够不同值，样本数严格大于参数数目。

显式声明x/y单位，程序只记录标签、不换算。支持带截距degree=1/2；多变量、任意非线性、GLM及误差变量模型未实现。sigma若提供，必须是每个响应的严格正标准差，最小化Σ((y-yhat)/sigma)²，对应方差权重1/sigma²；不能传入方差、任意权重或x误差。

原咖啡因教材复算是单独固定案例：四点带截距未加权OLS及待测面积反算，不把用户CSV标为教材来源或继承其数值资格。

## 完整流程

1. 读取完整SKILL.md、实际CSV与模型/单位/权重参数，保存输入和设置到Skill外全新目录；已有目录拒绝，不覆盖旧结果。
2. 校验列名、行数、ID、有限性和sigma；类别ID不能作为连续变量。文件级失败保留已取得输入及failure.json，非零退出。
3. 在缩放x的设计矩阵中执行NumPy lstsq，rcond=1e-12；要求满列秩且缩放设计条件数≤1e10，再把系数换回原x单位。这些阈值是工程准入规则，不是科学资格认证。
4. 保存原x/y、拟合值和残差y-yhat。报告系数次序/单位、样本数、秩、自由度、RSS、RMSE及独立的加权RSS。常量y的常规R²未定义，写null；加权拟合的R²明确按原y上的未加权带截距公式报告，不混称加权拟合优度。
5. 绘制实际观测、观测x范围内的拟合线和残差；输入sigma误差线不是置信区间。高R²不证明模型充分、因果、实验准确度或外推可靠。
6. 保存实际环境、输入哈希、参数、Skill快照、真实回执、图、SHA-256和结果ZIP。未执行标NOT_EXECUTED，不编造系数、文件或图片。

## 解释边界

本模块只做描述性拟合，不因程序运行成功宣称预测泛化。没有对应计算及假设时，不提供p值、置信区间、预测区间、检出限或显著性结论。独立性、误差分布、异方差和x误差需研究设计判断，秩检查不能替代。

教材案例仅复算转录表，不证明原仪器性能或原始数据真实性，保留署名及许可语境。截距不自动等于基线误差的物理原因；反算点超出标准范围须提示外推风险。

## 程序与来源

runtime/fit_csv.py提供完整run_skill流程：读取指令→检查CSV→固定数值工具→保存结果，不执行任意字符串公式。无模型模式记录Skill身份，不宣称语言模型理解了它。runtime/table-fitting-residuals.py保留教材固定复算入口；真实模型服务本轮不调用、不验收。

三个案例：咖啡因有来源表、合成直线、合成带sigma二次曲线。合成案例只验证软件，不是化学实测或泛化证据。

- [NIST Least Squares](https://www.itl.nist.gov/div898/handbook/pmd/section4/pmd431.htm)：准则和直线参数。
- [NIST残差诊断](https://www.itl.nist.gov/div898/handbook/pmd/section4/pmd44.htm)：R²不充分。
- [NumPy lstsq](https://numpy.org/doc/stable/reference/generated/numpy.linalg.lstsq.html)：秩、奇异值及rcond。
- 咖啡因来源与许可见README及runtime/data-provenance.json，不扩大为其他案例的来源。

## 解释规则与理论依据

区别固定HPLC入口（未加权带截距一次校准）与用户CSV入口（degree1/2，可选sigma WLS）。解释WLS时明确sigma为y标准差，行缩放1/sigma对应目标权重1/sigma²；e=y−yhat，RMSE分母n，常量y的R²未定义，WLS所报R²仍是原y未加权定义。不得据高R²推断机制或外推。

提供可复用预测式时优先scaled_coefficients：z=(x-scaled_x_center)/scaled_x_scale，yhat=Σb_k z^k；z无量纲、b_k全为y单位、center/scale为x单位。必须同时解释original_basis_diagnostic及warnings，REPLAY_UNSTABLE的原coefficients不能当稳定模型。无量纲相对回放门槛1e−10仅是观测x上的工程诊断，零尺度另作精确零比较；它不是实验不确定度或外推保证。Harvey§5.4支持OLS/WLS/残差与多项式背景，§12.5只作咖啡因题源；NIST手册与软件求解文档分层。数值误差经典阅读Burden/Faires第1章仅核验目录。来源访问限度见runtime/sources.json。
