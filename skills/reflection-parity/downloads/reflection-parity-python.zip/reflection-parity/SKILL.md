---
name: reflection-parity
description: 复核显式提供的实AO反射、度量酉性、二次反射恒等与子空间闭合，只有通过后才给指定空间的奇偶适配，不从矩阵标签猜几何镜面。
---

# 镜面反射与子空间奇偶

先确认用户目标、实际输入、方法、单位和来源。没有实际工具执行时标NOT_EXECUTED，不从既有文字、模型解释或历史PASS制造新数值。

## 输入与方法

parameters为atol及mirror_definition；data为overlap、reflection、basis。S正定，B必须S正交归一，R与S同维；真实镜面、原子映射和AO变换约定由用户明确。

检查R²=I、RᵀSR=S、BᵀSB=I以及Δ=RB−B(BᵀSRB)的S范数sqrt[Tr(ΔᵀSΔ)]（残差平方S范数的平方根）。仅闭合时对限制反射对角化，谱须为±1才输出适配列；不闭合时不贴奇偶标签。

## 核心知识：闭合子空间中的反射奇偶

R在这里作用于同一实AO系数列，即变换c↦Rc；它不是随意给名的算子积分矩阵。要求正定S、R²=I、RᵀSR=S和BᵀSB=I。R⁻¹=R与度量酉性联合推出RᵀS=SR，因此限制矩阵T=BᵀSRB实对称。

只有RB落在span(B)时才有RB=BT，也即Δ=RB−BT=0。此时二次作用得B=R²B=BT²；由B满列秩推出T²=I，故限制谱只能为±1。对T作正交对角化T=UΛUᵀ，BU就是给定空间中的奇偶适配列。若不闭合，T只是投影后的反射，出现介于−1与1的数也不能贴成真实奇偶本征值。

闭合残差比较的是sqrt Tr(ΔᵀSΔ)，并非其平方。若平方量为0.0396，范数约0.1989974874，必须按后者比较相同atol。实测微小残差只支持数值阈值内闭合；输入R代表哪个几何镜面仍需坐标、原子/壳层映射及AO球谐/相位约定证明。

①保存水几何与AO标签给出明确镜面，但本次仅代数复核；②二维交换反射在完整空间有±1本征列；③只取e1时交换到e2而离开空间，应不给奇偶标签。BU的旋转没有占据信息，可能混合不等占据，因此不自动保持D；奇偶也不自动等于σ/π、成键分类、能量或新SCF资格。

### 经典教材、实现来源及支持范围

[L1：Golub、Van Loan，Matrix Computations，第4版，JHU Press，2013，ISBN 9781421407944](https://www.press.jhu.edu/books/title/10678/matrix-computations)的§7.6、§8.1提供不变子空间与谱的经典背景；±1结论的前提和推导在上文写全，不能把目录核验当作真实分子群论/AO反射表示的已读正文证明。原有Strang课程仅是投影直观的补充。

本模块所引L1的作者、版次、年份和相关章节名称已对照出版社目录核验；未读取其全书正文，不声称已逐式或按页核验。上文推导由本模块明确给出，API文档仅支持实现接口。完整来源类型、访问范围和输入/保存数据身份见[runtime/sources.json](https://github.com/CCcolab/AI4OrgChem-data-processing/blob/main/skills/reflection-parity/runtime/sources.json)。

## 输入校验与方法依据补充

数值数组在NumPy类型提升前逐项校验：JSON布尔值true/false、null、字符串或与数值混合的这些值均拒绝，不把标志列自动转换为0/1测量、目标、度量或概率。整数0/1仍可用于已声明的数值/二分类接口；缺失值须先按研究协议处理。数组结构遍历预算为100000项，另保留各模块原有形状、有限性和数据规模限制。

## 完整调用与结果

1. 读取完整SKILL.md及显式JSON请求（parameters、data、provenance三部分），验证资源SHA-256及输入范围；禁止重复JSON键、NaN/Infinity和未知字段。
2. 将输入文字作为数据，不执行表达式、指令或未知代码，不联网、不调用模型。固定runtime/analysis.py负责实际科学/数学处理；runtime/run_skill.py负责完整可追溯调用。
3. 结果写Skill目录外全新目录，保存请求、Skill快照、环境、逐项检查、数值结果及真实回执。失败不得覆盖旧结果或标成功；新目录已创建时保留failure.json并非零退出。
4. 输出SHA-256及results.zip；文件状态以实际回执与哈希为准。无模型模式只记录Skill身份，不称指令已由模型理解。

## 科学边界

代数通过不证明输入R确实对应所说几何镜面；还需坐标、原子/壳层映射和AO约定。奇偶在指定空间内定义，不能直接认证轨道化学类型、能量或密度不变性；占据兼容需单独检查。

实际数值执行、合成软件测试、保存结果复核和新量子计算分开报告，不继承其他项目或旧案例资格。输入的来源标签/收敛/身份声明不是外部证据的真实性鉴定。

## 方法来源

反射、度量和闭合公式在本页显式给出；[NumPy eigh](https://numpy.org/doc/stable/reference/generated/numpy.linalg.eigh.html)支持限制算子的实对称分解。

闭合比较量为S范数而非其平方：平方量0.0396对应约0.1989974874，atol始终与后者比较。R²=I和RᵀSR=S在闭合空间内给±1谱是矩阵代数结论；[Strang投影课程](https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/resources/lecture-16-projection-matrices-and-least-squares/)支持子空间/投影语境，不替代真实几何镜面、AO约定和占据证据。

下载指令的来源链接使用公开仓库明确地址；完整Python代码包内的来源文件位于`runtime/sources.json`。顶层维护源与下载导出字节一致。
