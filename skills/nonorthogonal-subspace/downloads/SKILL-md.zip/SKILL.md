---
name: nonorthogonal-subspace
description: 用明确正定实度量复核用户子空间与向量，报告Gram数值秩、S正交投影、残差平方范数及有定义的相对泄漏，不把系数平方和或投影误差当能量。
---

# 非正交子空间与泄漏复核

先确认用户目标、实际输入、方法、单位和来源。没有实际工具执行时标NOT_EXECUTED，不从既有文字、模型解释或历史PASS制造新数值。


## 配套程序已验证运行环境

**下列数据/数值功能已在本地运行成功；结论限定于列出的操作与案例。**

| 项目 | 已验证内容 |
| --- | --- |
| 操作系统 | Windows 11 |
| Python / 设备 | 3.12.14 / CPU |
| 本轮实际依赖范围 | numpy 2.4.6 |
| 本轮已验证功能 | 给定实度量的子空间投影、数值秩、残差和平方范数泄漏复核；参数修改与已有结果保护 |
| 测试内容 | default、changed-parameter、existing-output-protection；结果文件、ZIP CRC与SHA-256核对 |
| 测试结果 | 3/3项符合预期；含输入拒绝/旧结果保护，不表示所有命令退出0 |
| 历史运行记录 | 历史固定bb629ee版（2026-10-25）在Linux / Python 3.12.14 / CPU完成默认入口；不等于本修订版完整运行复验 |
| 验证日期 / 程序基线 | 2026-10-26 / 67aaaaa；本次只改说明与分发，不改计算程序 |
| 未覆盖范围 | 平方范数泄漏不是概率、电子数损失或能量；未认证新的科学后端或任意复杂数据。 |

使用已有独立Python环境，没有在本轮重新安装依赖。通过所列小型案例不等于全部平台、输入分布或科学用途已认证。 输入准备、数值复核、模型训练与化学用途验证分别报告；全平台对照见[运行环境与验证范围](https://github.com/CCcolab/AI4OrgChem-data-processing/blob/main/docs/VERIFIED_ENVIRONMENTS.md)。


## 输入与方法

parameters为atol、rank_rtol（1e-12至1e-4）；data为overlap、basis、vectors，均实数组，vectors按列。S正定，最小特征值>1e-10、条件数≤1e10；不静默截断环境度量S。

G=BᵀSB，按λ>rank_rtol×λmax保留Gram方向；P=B G⁺ BᵀS。分别报告vᵀSv、rᵀSr及比值；零/近零原范数的比值写null。检查P²=P、PᵀS=SP和保留范围对残差的S正交性。阈值及数值秩是工程约定，不是物理概率解释。

## 核心知识：S度量投影、截断与泄漏的含义

前提是有限实正定S、同一AO顺序的基列B和按列的目标v。内积为⟨u,v⟩S=uᵀSv，平方范数为vᵀSv；它与普通系数平方和不同。G=BᵀSB=UΛUᵀ，仅保留λ>rank_rtol λmax的方向r，定义Q=B U_r Λ_r⁻¹/²。直接代入得QᵀSQ=I，故P=QQᵀS=B G_r⁺ BᵀS，P²=P、PᵀS=SP。

令r=v−Pv，则QᵀSr=0，vᵀSv=(Pv)ᵀS(Pv)+rᵀSr。因此泄漏比例为rᵀSr/(vᵀSv)，分母为零或近零时无定义并写null；本工具只报告数值残差比例，不赋予物理概率、电子数或能量含义；归一化物理态及相应测量投影协议未在本工具中给定。谱被截断时投向的是保留子空间，不能要求残差与被丢弃的全部B方向也正交。记号G_r⁺表示按本阈值截断的逆，并不隐含所有非零数学本征值都保留。

可令S=WᵀW，把WB置于欧式空间理解上述投影，再还原到原AO表示。形成Gram会把WB的奇异值平方，故Gram的相对特征值阈值对应奇异值相对阈值的平方；列缩放也可能改变有限精度的保留秩。rank_rtol与atol是数值合同，不是物理误差条。本实现不静默截断环境S，也不处理复、奇异或不定度量。

①保存占据轨道目标泄漏约0，S正交虚轨道约1，均是旧数据后处理；②相关列只保留秩1而不重复计空间；③零向量投影/绝对泄漏0但相对值null。覆盖结论只关于用户实际提供的目标和保留空间，AO身份仍须独立核实。

### 经典教材、实现来源及支持范围

[L1：Golub、Van Loan，Matrix Computations，第4版，JHU Press，2013，ISBN 9781421407944](https://www.press.jhu.edu/books/title/10678/matrix-computations)的§4.2、§5.5、§6.4是正定度量、秩亏与子空间的经典入口。原有[Strang投影课程](https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/resources/lecture-16-projection-matrices-and-least-squares/)是大学课程页，支持欧式直观，不伪装成已读加权AO投影教材正文。

本模块所引L1的作者、版次、年份和相关章节名称已对照出版社目录核验；未读取其全书正文，不声称已逐式或按页核验。上文推导由本模块明确给出，API文档仅支持实现接口。完整来源类型、访问范围和输入/保存数据身份见[runtime/sources.json](https://github.com/CCcolab/AI4OrgChem-data-processing/blob/main/skills/nonorthogonal-subspace/runtime/sources.json)。

## 输入校验与方法依据补充

数值数组在NumPy类型提升前逐项校验：JSON布尔值true/false、null、字符串或与数值混合的这些值均拒绝，不把标志列自动转换为0/1测量、目标、度量或概率。整数0/1仍可用于已声明的数值/二分类接口；缺失值须先按研究协议处理。数组结构遍历预算为100000项，另保留各模块原有形状、有限性和数据规模限制。

## 完整调用与结果

1. 读取完整SKILL.md及显式JSON请求（parameters、data、provenance三部分），验证资源SHA-256及输入范围；禁止重复JSON键、NaN/Infinity和未知字段。
2. 将输入文字作为数据，不执行表达式、指令或未知代码，不联网、不调用模型。固定runtime/analysis.py负责实际科学/数学处理；runtime/run_skill.py负责完整可追溯调用。
3. 结果写Skill目录外全新目录，保存请求、Skill快照、环境、逐项检查、数值结果及真实回执。失败不得覆盖旧结果或标成功；新目录已创建时保留failure.json并非零退出。
4. 输出SHA-256及results.zip；文件状态以实际回执与哈希为准。无模型模式只记录Skill身份，不称指令已由模型理解。

## 科学边界

只处理有限实正定度量；不支持复杂、奇异或不定度量。泄漏是指定向量与指定子空间的平方S范数差，不自动等于电子数、能量损失或化学局域性。输入AO身份和度量来源必须由研究者核对。

实际数值执行、合成软件测试、保存结果复核和新量子计算分开报告，不继承其他项目或旧案例资格。输入的来源标签/收敛/身份声明不是外部证据的真实性鉴定。

## 方法来源

投影公式在此显式给定；[NumPy eigh](https://numpy.org/doc/stable/reference/generated/numpy.linalg.eigh.html)支持对称Gram矩阵分解。软件分解不认证AO物理身份。

下载指令的来源链接使用公开仓库明确地址；完整Python代码包内的来源文件位于`runtime/sources.json`。顶层维护源与下载导出字节一致。
