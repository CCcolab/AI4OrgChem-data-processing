# 态集合与固定权重复核

核对已有态集合完整性、来源与固定非负归一化权重，不运行多态优化或推断统计权重。 正式入口提供准备、已有数据复核和结果JSON导入。输入准备不会运行科学求解器；数值复核仅证明输入通过所列检查。

[完整SKILL.md代码](SKILL.md?plain=1) · [下载完整指令](downloads/multistate-size-comparison-skill.zip) · [Python代码包](downloads/multistate-size-comparison-python.zip) · [源文件SHA-256](runtime/SHA256SUMS.txt)

## 已在本地运行成功的环境与功能

**本Skill的正式功能已完成本地运行验证，并通过GitHub下载包复验。**

| 项目 | 已验证内容 |
| --- | --- |
| 操作系统 | Windows 11 |
| Python | 3.12.14 |
| 运行方式 | 本地独立Python环境、CPU |
| 依赖 | NumPy 2.4.6；准备模式仅用Python标准库 |
| 成功运行的功能 | 准备复核请求、复核已有结果、导入已有JSON、保存结果及SHA-256 |
| 测试内容 | 三个正式案例、参数修改、预期错误拒绝与失败保存、旧结果保护；准备模式另以标准库单独运行 |
| 验证结果 | 本地8/8项、GitHub下载复验8/8项均符合预期（含预期失败测试） |
| 验证日期 | 2026-10-26 |

“已运行成功”对应上述正式功能。准备步骤的PREPARED_NOT_EXECUTED表示请求准备完成、没有执行外部科学计算，不表示程序失败。新求解器调用的开发预览另有独立范围，不影响本表已通过的准备、复核及文件导入结论。

## 知识点与科学边界

比较多电子态或多尺寸体系前，先定义每个体系的组成、态身份、共同参考、所用方法/基组、预期态集合和权重含义。不同组成的总能不能未经反应式、计量系数与参考约定直接相减解释物性。

本地复核器逐尺寸核对显式期望态集合，无缺失、重复或多余；只做非负、显式固定且各尺寸和为1的权重求和 ΣwᵢEᵢ。它不是有符号反应能/LDE 组装器，不自动生成 Boltzmann 布居、激发谱或自由能。不自动重归一化用户权重，也不凭浮点算术证明状态正交、电子态连续性或后端端点资格。

要求 1至16 个尺寸标签、总计1至128项态记录，明确 energy_hartree、weight、eligible、来源与态定义；协议/方法/基组身份须匹配。合成例01是完整集合；例02缺失 large/b；例03将 small/a 资格设为 false，后两例均应拒绝。真实新计算应由用户已有各态求解器按协议生成，失败/待验态不得填零或以旧 PASS 顶替。

教材依据、推导及实现来源见 [完整 Skill](SKILL.md?plain=1) 与 [来源说明](runtime/sources.json)。经典教材用于理论背景，官方软件文档用于 API；不将 API 文档称为教材级物理证明。本页正式的准备、数学复核与文件导入已经通过上述本地运行验证；外部求解器的新实算对接单列开发预览。

## 依赖与首次操作

下载代码包并在有权限的短路径解压，例如Windows的 `C:/s/multistate-size-comparison`，进入该目录执行下列命令。使用自己的Python环境，不依赖本项目Runtime、Docker、安装登记或模型账号。

本次验证Python3.12.14。准备模式仅用标准库；数组复核及结果导入后的复核需要NumPy2.4.6。 仅缺依赖时由用户自行执行 `python -m pip install -r runtime/requirements.txt`；程序不安装软件、不联网、不切换环境。正式三个案例不需要PySCF或其它量子化学软件。

## 三个对应案例

| 程序 | 操作 | 输出 |
| --- | --- | --- |
| 01_prepare.py | 读取完整Skill和01.json，保存输入计划 | PREPARED_NOT_EXECUTED；不生成新数值 |
| 02_review.py | 复核01.json中的既有数组或人工账本 | COMPLETE_DEFINED_SCOPE及逐项检查 |
| 03_import_result.py | 将01.json作为已有结果文件读取并复核 | result_file_imports=1，backend_calls=0及原文件SHA-256 |

```powershell
python runtime/examples/01_prepare.py --output C:/s/out/multistate-size-comparison-prepare01
python runtime/examples/02_review.py --output C:/s/out/multistate-size-comparison-review01
python runtime/examples/03_import_result.py --output C:/s/out/multistate-size-comparison-import01
```

01.json与02.json是明确来源的两份复核输入；03.json是故意不合格反例，非零退出是预期。数据来源看各自provenance；保存的历史计算数组与人工示例均不代表本次进行了新实算。

## 修改参数与结果对应

先复制 `runtime/examples/01.json` 到包外（如 `C:/s/my-input.json`），在编辑器将 `parameters.weight_atol` 改为 `2e-10` 后另存，再运行：

```powershell
python runtime/run_skill.py --mode review --input C:/s/my-input.json --output C:/s/out/multistate-size-comparison-changed01
```

该修改的对应结果：完整人工态集合仍通过；也可将同一尺寸两态权重一并改为0.5/0.5，不能仅改单态破坏归一化。

不要直接修改受哈希保护的包内程序/实例再自动重算清单掩盖变化。输入必须是 parameters、data、provenance 三部分；字段、数组与单位参照完整 SKILL.md、[复核源码](runtime/analysis.py) 和 [输入实例](runtime/examples/01.json)。参数容差不是物理误差条，放宽它不能修正错误方法。

## 使用用户已有结果

用户已有程序导出的JSON须符合本Skill的parameters/data/provenance字段、单位和数组顺序，详见[完整Skill](SKILL.md?plain=1)、[复核程序](runtime/analysis.py)及[实例](runtime/examples/02.json)。在包外建立导入请求，例如：

```json
{"parameters": {"result_file": "C:/s/my-exported-result.json"}, "data": {},
 "provenance": {"kind": "USER_RESULT", "description": "说明软件、方法、几何、单位与原生日志来源"}}
```

```powershell
python runtime/run_skill.py --mode import --input C:/s/import-request.json --output C:/s/out/multistate-size-comparison-user01
```

result_file须为绝对路径的常规JSON文件且不超过2MB；不把文件文字当代码执行。保存原文件字节与SHA-256后执行同样的数学复核。来源标签和converged只作为输入声明，不能独立认证其真实性。

## 完整调用模板

```python
from pathlib import Path
import importlib.util

page = Path("C:/s/multistate-size-comparison").resolve()
spec = importlib.util.spec_from_file_location("skill_review", page / "runtime/run_skill.py")
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
receipt = bridge.run_skill(mode="review", request_file="C:/s/my-input.json", output_dir="C:/s/out/review-new")
```

程序实际读取并保存SKILL.md身份，再验证输入、复核及写结果。没有调用语言模型，不称模型已理解指令。正式入口不接受--backend或--execute。

## 结果保存与失败处理

写包外全新目录，禁止覆盖。准备模式另保存input-plan.json（复核输入计划，不是新计算软件输入）。保存request.json、SKILL.used.md、run-receipt.json；复核时另有review-request.json、result.json。导入时另存source-result.original.json和import-return.json。SHA256SUMS.txt、results.zip及其侧SHA用于保存和复核。

数值检查失败退出1；输入/解析等异常退出2。合法新目录已经创建时保存failure.json、实际回执和已有产物；参数解析、已有输出、危险或超限输入可在写入前拒绝。结果以程序回执、检查项和实际文件为准，不把失败结果或旧PASS当作新合格端点。输入准备只做结构及来源声明检查，不验收科学端点。

## 开发预览

需调用用户现有程序产生新计算结果时，先读[独立开发预览](runtime/development_preview/README.md)。任意Python适配器、原生请求及可选PySCF模板已从正式入口移至该目录；新真实后端完整实算没有完成验收。预览需用户明确选择，并不属于上述三个已验证的常规功能。没有自动安装或启动环境，不以目录重命名提升科学资格。
